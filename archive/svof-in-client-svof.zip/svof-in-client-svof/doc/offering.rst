Svof Corpse stuff
======================================
The addon has several aliases that are usefulf for dealing with corpse management - getting them, giving away, offering, defiling or sanctifying with them.


Aliases
^^^^^^^^^^
.. glossary::

  voffer
  	Offers everything. Made before 'offer corpses' existed, this now simply uses that command.

  vget
  	Retrieves all corpses from the ground.

  vgive *person*
  	Gives all corpses away to a person.
    
  vput *thing*
    Puts all the corpses into whatever you specify.

  vdefile
  	Defiles with corpses. Use *undoall* to stop defiling.

  vsanctify
  	Sanctifies with corpses. Use *undoall* to stop sanctifying.

  undoall
    Cancels vdefile/vsanctify.

  vkill
  	Just kidding, it doesn't exist.
